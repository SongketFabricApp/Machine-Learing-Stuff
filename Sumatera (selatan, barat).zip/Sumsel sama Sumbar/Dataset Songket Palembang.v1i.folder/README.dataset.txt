# Dataset Songket Palembang > 2023-11-18 3:45pm
https://universe.roboflow.com/klasifikasi-tenun/dataset-songket-palembang

Provided by a Roboflow user
License: CC BY 4.0


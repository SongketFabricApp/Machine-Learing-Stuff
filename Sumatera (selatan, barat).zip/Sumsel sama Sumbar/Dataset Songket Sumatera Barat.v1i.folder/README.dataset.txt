# Dataset Songket Sumatera Barat > 2023-11-18 3:51pm
https://universe.roboflow.com/klasifikasi-tenun/dataset-songket-sumatera-barat

Provided by a Roboflow user
License: CC BY 4.0


# Dataset > 2023-11-09 12:58am
https://universe.roboflow.com/klasifikasi-tenun/dataset-eeg2y

Provided by a Roboflow user
License: CC BY 4.0


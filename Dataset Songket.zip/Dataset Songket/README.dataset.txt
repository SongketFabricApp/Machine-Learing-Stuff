# Dataset Songket Riau > 2023-11-17 10:14am
https://universe.roboflow.com/klasifikasi-tenun/dataset-songket-riau

Provided by a Roboflow user
License: CC BY 4.0

